// the functions associated with preload, create and update.
var actions = { preload: preload, create: create, update: update };
// the Game object used by the phaser.io library
var game = new Phaser.Game(790, 400, Phaser.AUTO, "game", actions);

var speed = 250;

var randx;
var randy;

var goods = [];
var bads = [];
var tresbads = [];

var difficulty = 8;

var player;

var playerspeed = 100;

var instrucount = 0;

var text1;
var text2;
var text3;
var text4;

var score = 0;

var scorechange = false;

// Loads all resources for the game and gives them names.
function preload() {
  game.load.image("flappy", "../assets/flappy-cropped.png");

  game.load.image("good", "../assets/flappy_superman.png");
  game.load.image("bad", "../assets/flappy_batman.png");
  game.load.image("tresbad", "../assets/flappy_frog.png");
}

// Initialises the game. This function is only called once.
function create() {

  var shapeInterval;
  game.stage.setBackgroundColor("#FFFFFF");
  player = game.add.sprite(395, 200, "flappy");
  game.physics.arcade.enable(player);
  game.physics.startSystem(Phaser.Physics.ARCADE);


  game.input.keyboard.addKey(Phaser.Keyboard.SPACEBAR).onDown.add(jumpup);

  game.input.keyboard.addKey(Phaser.Keyboard.RIGHT).onDown.add(jumpright);

  game.input.keyboard.addKey(Phaser.Keyboard.LEFT).onDown.add(jumpleft);

  game.input.keyboard.addKey(Phaser.Keyboard.DOWN).onDown.add(jumpdown);

  game.input.keyboard.addKey(Phaser.Keyboard.UP).onDown.add(jumpup);


  player.body.collideWorldBounds = true;
  player.body.bounce.setTo(0.9, 0.9);
  player.anchor.setTo(0.5, 0.5);




  function generateInstructions() {
    if (instrucount == 0){
      text1 = game.add.text(20, 20, "Superman = + 5");
      text2 = game.add.text(20, 45, "Batman = - 5");
      text3 = game.add.text(20, 70, "Toad = Très Bad");
      text4 = game.add.text(20, 95, "The game will start soon - and it gets harder over time!");
      instrucount++;
    }
    else if (instrucount == 1){
      text1.text = "";
      text2.text = "";
      text3.text = "";
      text4.text = "";
      game.time.events.remove(instructionloop);
    }
  }

  scorelbl = game.add.text(750, 20, String(score));


  instructionInterval = 7 * Phaser.Timer.SECOND;
      instructionloop = game.time.events.loop(
        instructionInterval,
        generateInstructions
      );



  shapeInterval = difficulty * Phaser.Timer.SECOND;
      speedloop = game.time.events.loop(
        shapeInterval,
        generateShapes
      );

}

// This function updates the scene. It is called for every new frame.
function update() {


  if (score < 0){
    gameOver();
  }

  function clearGameCache () {
      game.cache = new Phaser.Cache(game);
      game.load.reset();
      game.load.removeAll();
  }

  if (score >= 12){
    scorechange = true;
  }






  function gameOver(){

  game.add.text(400, 200, "GAME OVER!");
  game.paused = true;
  }


  function scoreupdategood(player, superman){
    superman.destroy();
    score = score + 5;
    scorelbl.setText(String(score));
  }

  function scoreupdatebad(player, batman){
    batman.destroy();
    score = score - 5;
    scorelbl.setText(String(score));
  }

  function scoreupdatetresbads(player, toad){
    toad.destroy();
    score = Math.sqrt(score)-(Math.sqrt(score)%1);
    scorelbl.setText(String(score));
  }

  game.physics.arcade.overlap(
    player,
    goods,
    scoreupdategood
  );

  game.physics.arcade.overlap(
    player,
    bads,
    scoreupdatebad
  );

  game.physics.arcade.overlap(
    player,
    tresbads,
    scoreupdatetresbads
  );

}

function jumpup() {
  player.body.velocity.y = -playerspeed;
}

function jumpright() {
  player.body.velocity.x = playerspeed;
}

function jumpleft() {
  player.body.velocity.x = -playerspeed;
}

function jumpdown() {
  player.body.velocity.y = playerspeed;
}

function upgradeDifficulty() {
  if (difficulty > 3) {
  difficulty = difficulty - 1;
  }
  else if (difficulty > 3){
    difficulty = difficulty - 0.5;
  }
  else if (difficulty > 1){
    difficulty = difficulty - 0.25;
  }
  else if (difficulty > 0.125){
    difficulty = difficulty - 0.125;
  }
  console.log("Difficulty is now " + String(difficulty));
}

function generateShapes() {
  console.log("Shapes (hopefully) Generating");
  if (difficulty > 3) {
  difficulty = difficulty - 1;
  playerspeed = playerspeed + 5;
  }
  else if (difficulty > 3){
    difficulty = difficulty - 0.5;
    playerspeed = playerspeed + 5;
  }
  else if (difficulty > 1){
    difficulty = difficulty - 0.25;
    playerspeed = playerspeed + 5;
  }
  else if (difficulty > 0.125){
    difficulty = difficulty - 0.125;
    playerspeed = playerspeed + 5;
  }
  if (difficulty > 0.125) {
    console.log("Difficulty changing - it's now " + String(difficulty));
    shapeInterval = difficulty * Phaser.Timer.SECOND;
    console.log(shapeInterval);

    game.time.events.remove(speedloop);
    speedloop = game.time.events.loop(
      shapeInterval,
      generateShapes
    );

}

  speed = speed + 25;
  var types = ["good", "bad", "tresbad"];
  var randtype = game.rnd.integerInRange(0, 2);
  var rltype;
  var newrand = game.rnd.integerInRange(0, 1);
  if (randtype == 0){
      if (scorechange) {

        if (newrand == 1){
          rltype = "superman";
        }
        else {
          rltype = "batman";
          }
      }
      else {
        rltype = "superman";
      }
    }
    else if (randtype == 1){
      rltype = "batman";
    }
    else {
      rltype = "toad";
    }



  var randside = game.rnd.integerInRange(1, 3);
  if (randside == 1){
    randy = game.rnd.integerInRange(50, 350);
    randx = - 50;
  }
  else if (randside == 2) {
    randy = - 50;
    randx = game.rnd.integerInRange(50, 740);
  }
  else if (randside == 3) {
    randy = game.rnd.integerInRange(50, 350);
    randx = 840;
  }

  if (randtype == 0) {
    console.log("superman added");
    good = game.add.sprite(randx, randy, types[randtype]);
    goods.push(good);
    game.physics.arcade.enable(good);
    if (randside == 1) {
      good.body.velocity.x = speed;
    }
    else if (randside == 2){
      good.body.velocity.y = speed;
    }
    else if (randside == 3) {
      good.body.velocity.y = -speed;
    }
    console.log(good);
  }
  else if (randtype == 1) {
    console.log("batman added");
    bad = game.add.sprite(randx, randy, types[randtype]);
    bads.push(bad);
    game.physics.arcade.enable(bad);
    if (randside == 1) {
      bad.body.velocity.x = speed;
    }
    else if (randside == 2){
      bad.body.velocity.y = speed;
    }
    else if (randside == 3) {
      bad.body.velocity.y = -speed;
    }
    console.log(bad);
  }
  else if (randtype == 2) {
    console.log("toad added");
    tresbad = game.add.sprite(randx, randy, types[randtype]);
    tresbads.push(tresbad);
    game.physics.arcade.enable(tresbad);
    if (randside == 1) {
      tresbad.body.velocity.x = speed;
    }
    else if (randside == 2){
      tresbad.body.velocity.y = speed;
    }
    else if (randside == 3) {
      tresbad.body.velocity.y = -speed;
    }
    console.log(tresbad);
  }




}
